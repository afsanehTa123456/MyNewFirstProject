package com.example.mynewfirstproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ReviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
        Intent i=getIntent();

        String UName=i.getStringExtra("UserName");
        final TextView txtUName=findViewById(R.id.etxUNameId);
        txtUName.setText(UName);

        String LName=i.getStringExtra("LastName");
        final TextView txtLName=findViewById(R.id.etxLNameId);
        txtLName.setText(LName);

        String email=i.getStringExtra("MailAddress");
        final TextView txtMailAdd=findViewById(R.id.etxMailId);
        txtMailAdd.setText(email);

        String txtAge=i.getStringExtra("Age");
        final TextView txtAges=findViewById(R.id.etxAgeId);
        txtAges.setText(txtAge);


        Button btnOk=findViewById(R.id.btnOkId);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(ReviewActivity.this,"successful!",Toast.LENGTH_LONG).show();

            }
        });
        Button editbtn=findViewById(R.id.btnEditId);
        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent();

                String userName=txtUName.getText().toString();
                i.putExtra("userName",userName);

                String lastName=txtLName.getText().toString();
                i.putExtra("lastName",lastName);

                String mailAdd=txtMailAdd.getText().toString();
                i.putExtra("mailAdd",mailAdd);

                String age=txtAges.getText().toString();
                i.putExtra("age",age);

                setResult(Activity.RESULT_OK,i);

                finish();

            }
        });
    }
}
